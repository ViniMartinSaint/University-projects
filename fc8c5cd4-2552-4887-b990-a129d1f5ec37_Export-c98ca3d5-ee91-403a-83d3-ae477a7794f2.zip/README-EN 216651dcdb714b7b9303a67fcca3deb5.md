# README-EN

# University Projects

> This repository it's based on a mine College project. Nowadays I am studying "Technology of Data Science”, training with Python and SQL.
> 

First of all, before I start with the codes, I need to show all the logic behind these projects. Uninter, the college that I’m studying, separates the class in some knowledge about Python language, so I’m going to explain which tools I need to use in all the Challenges 

## 1ª **Phase**

During the curse, we use learn very basic commands in Python language.

These were the functions that I learned in this Phase:

- **Sequential algorithms. Data, Variables, and Input and Output Commands**
- **Sequential algorithms. Structures of selection or decision structures**

## Projects of the 1ª Phase

### 1ª Question

1. **project context**
    
    Imagine yourself as the programmer responsible for the construction of a sales app for one company X that sells wholesale. One sales strategy of this company X is to give bigger discounts per unit according to the table below:
    
    | Quantities | Desconto |
    | --- | --- |
    | Until 9 | 0% of the unit |
    | Between 10 and 99 | 5% of the unit |
    | Between 100 and 999 | 10% of the unit |
    | From 1000 to more | 15% of the unit |
    
2. **Code requirements**
    
    Elaborate on an application in python that:
    
    - Enter with a product unit value;
    - Enter the amount quantity of this product;
    - The application must return the total value without discount;
    - The application must return the total value with a discount;
    - Must use structures If, Elif, and Else (requirement 1 by 1)
    - Show an example of the console output of purchases bigger than 10 Units (To show the applied discount.
    
3. **Conclusion** 
    
    It’s possible the complete code as “1_Questão.py”:
    
    ![Untitled](README-EN%20216651dcdb714b7b9303a67fcca3deb5/Untitled.png)
    
4. **Difficulties**  
    - My principal difficulties were the necessity of commentaries in the code, I got a little bit confused. I don’t know yet how to produce an important comment in the code, so I would like some tips to evolve this ability later.
    - Commits, how can I be more direct about the commits description